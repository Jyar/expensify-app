import React from 'react';

const HelpPage= () => (
    <div>
      help page 
    </div>
  );
 
  export default HelpPage;